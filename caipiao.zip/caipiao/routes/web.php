<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('getsome', 'TestController@getsome');

Route::namespace('Admin')->group(function () {
	Route::get('/admin', 'AdminController@index')->name('admin')->middleware('auth.admin:admin');//
    // 在 「App\Http\Controllers\Admin」 命名空间下的控制器
	Route::any('/admin/index', 'AdminController@index')->name('index')->middleware('auth.admin:admin');
	Route::any('admin/user_setting', 'AdminController@user_setting')->name('user_setting');
	Route::any('admin/user_password', 'AdminController@user_password')->name('user_password');
	Route::any('admin/welcome_1', 'AdminController@welcome_1')->name('welcome_1');
	Route::any('admin/welcome_2', 'AdminController@welcome_2')->name('welcome_2');
	Route::any('admin/welcome_3', 'AdminController@welcome_3')->name('welcome_3');
	Route::any('admin/table', 'AdminController@table')->name('table');
	Route::any('admin/form', 'AdminController@form')->name('form');
	
	Route::any('admin/login_1', 'LoginController@login_1')->name('login_1');
	Route::any('admin/login_2', 'LoginController@login_2')->name('login_2');
	Route::get('admin/login', 'LoginController@showLoginForm')->name('admin.showLoginForm');
	Route::post('admin/login', 'LoginController@login')->name('admin.login');
	Route::any('admin/logout', 'LoginController@logout')->name('admin.logout');
	
	Route::any('admin/getsome', 'AdminController@getsome');
});


Route::namespace('Api')->group(function(){
	Route::get('login', 'NusersController@login');
	Route::post('dologin', 'NusersController@dologin');
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

// Auth::routes();

// Route::get('/home', 'HomeController@index')->name('home');

<?php echo e($slot); ?>

<?php /**PATH D:\www\laravel\demo618\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
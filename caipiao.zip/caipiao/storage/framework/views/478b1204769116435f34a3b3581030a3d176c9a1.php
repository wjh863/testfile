<!DOCTYPE html>
<html>
    <head>
        <title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
    </head>
    <body>
        <?php $__env->startSection('sidebar'); ?>
            This is the master sidebar.
        <?php echo $__env->yieldSection(); ?>

		<form action="<?php echo e(url('/dologin')); ?>" method="post">
			<input type="text" name="uname" value="">
			<input type="password" name="pwd" value="">
			
			<input type="submit" value="submit">
		</form>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html><?php /**PATH D:\www\laravel\demo618\resources\views/api/login.blade.php ENDPATH**/ ?>
<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class Nusers extends Model
{
    //
	protected $table = 'nusers';
	protected $primaryKey = 'id';
	
	
	
}

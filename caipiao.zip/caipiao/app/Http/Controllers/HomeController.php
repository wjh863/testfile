<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
		// if (Auth::check()) {
			// echo '用户已经登录了...';
			// // 获取当前通过认证的用户...
			// // $user = Auth::user();
			// $data = $request->session()->all();
			// // echo '<pre>'; var_dump($user);
			// echo '<pre>'; var_dump($data);
			
			// //  获取当前通过认证的用户 ID...
			// echo $id = Auth::id();
		// }
        return view('home');
    }
}

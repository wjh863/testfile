<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function index(Request $request)
	{
		// if (Auth::guard('admin')->check()) {
			// echo '111111110000000000';
			// $data = $request->session()->all();
			// echo '<pre>'; var_dump($data);echo '<pre/>';
			// $user = Auth::guard('admin')->user();
			// echo '<pre>'; var_dump($user);echo '<pre/>';
		// } else {
			// echo '未认证';
			// $user = Auth::user();
			// $data = $request->session()->all();
			// // echo '<pre>'; var_dump($user);echo '<pre/>';
			// echo '<pre>'; 
			// var_dump($data);
			// $id = Auth::id();
			// echo 'id:'.$id;
			// echo '<pre/>';
		// }
		return view('admin/index');
	}
	
	public function user_setting()
	{
		// if (Auth::guard('admin')->check()) {
			// echo '111111110000000000';
			
		// } else {
			// echo '未认证';
		// }
		return view('admin/user_setting');
	}
	
	public function user_password()
	{
		return view('admin/user_password');
	}
	
	public function welcome_1()
	{
		return view('admin/welcome_1');
	}
	
	public function welcome_2()
	{
		return view('admin/welcome_2');
	}
	
	public function welcome_3()
	{
		return view('admin/welcome_3');
	}
	
	public function table()
	{
		return view('admin/table');
	}
	
	public function form()
	{
		return view('admin/form');
	}
	
	// public function login_1()
	// {
		// return view('admin/login_1');
	// }
	
	// public function login_2()
	// {
		// return view('admin/login_2');
	// }
	
	// public function login_3()
	// {
		// return view('admin/login_3');
	// }
	
	
	//
	public function getsome()
	{
		echo '101010101-----';
	}
	
	// public function logout()
    // {
        // // $this->guard()->logout();

        // // $request->session()->flush();

        // // $request->session()->regenerate();
// echo '0909090909090';exit;		
		// // Auth::logout();
// echo '1212121121212';exit;
        // return view('admin/index');//redirect('admin/login');
    // }
	
	
}

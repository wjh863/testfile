<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/admin/index';//RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest:admin')->except('logout');
    }
	
	public function showLoginForm()
	{
		return view('admin/login_3');
	}
	
	public function guard()
	{
		// $ret = Auth::guard('admin');
		// var_dump($ret);
		return Auth::guard('admin');
	}
	
	public function login_(Request $request)
	{
		echo '11111111';// var_dump($request);
	}
	
	/**
      * 重写验证时使用的用户名字段
      */
	public function username()
	{
		return 'uname';
	}
	 
	public function logout(Request $request)
    {
        $this->guard()->logout();

        $request->session()->flush();

        $request->session()->regenerate();

		// Auth::logout();
// echo '1212121121212';exit;
        return redirect('/admin/login'); //view('admin/login_3');//
    }
	
	public function login_1()
	{
		return view('admin/login_1');
	}
	
	public function login_2()
	{
		return view('admin/login_2');
	}
}

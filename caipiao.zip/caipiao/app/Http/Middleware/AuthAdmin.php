<?php

namespace App\Http\Middleware;

use Closure;

class AuthAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
		// $bl = auth()->guard($guard)->guest();
		// dump($bl);
		// dump($guard);
		// exit;
		if(auth()->guard($guard)->guest())
		{
			if($request->ajax() || $request->wantsJson()) 
			{
				return response('error', 401);
			}
			return redirect()->guest('/admin/login');
		}
		// echo '11111'; exit;
        return $next($request);
    }
	
	
	
}
